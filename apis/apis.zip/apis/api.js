// === api.js (reemplaza TODO) ===
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '.env') });
const express = require('express');
const sql = require('mssql');

const app = express();
app.use(express.json());

console.log('Boot file:', __filename);
console.log('ENV:', {
  server: process.env.SQL_SERVER,
  db: process.env.SQL_DATABASE,
  user: process.env.SQL_USER,
  encrypt: process.env.SQL_ENCRYPT
});

const sqlConfig = {
  server: process.env.SQL_SERVER,
  database: process.env.SQL_DATABASE,
  user: process.env.SQL_USER,
  password: process.env.SQL_PASSWORD,
  options: { encrypt: process.env.SQL_ENCRYPT === 'true', trustServerCertificate: false },
  pool: { max: 10, min: 0, idleTimeoutMillis: 30000 }
};

let pool;
async function getPool() { if (pool) return pool; pool = await sql.connect(sqlConfig); return pool; }

// raíz
app.get('/', (_req, res) => res.send('API MedPresc ✅'));

// debug conexión
app.get('/debug/db', async (_req, res) => {
  try {
    const p = await getPool();
    const ping = await p.request().query('SELECT 1 AS ok');
    const tables = await p.request().query('SELECT TOP 5 name FROM sys.tables ORDER BY name');
    res.json({ ok: ping.recordset[0].ok, tables: tables.recordset });
  } catch (err) {
    console.error('DEBUG /debug/db:', err);
    res.status(500).json({
      error: 'DB_ERROR',
      name: err.name,
      code: err.code,
      number: err.number,
      message: err.message
    });
  }
});

// lista rutas para confirmar qué está cargado
app.get('/__routes', (_req, res) => {
  const routes = [];
  app._router.stack.forEach((m) => {
    if (m.route && m.route.path) {
      routes.push({ method: Object.keys(m.route.methods)[0].toUpperCase(), path: m.route.path });
    }
  });
  res.json(routes);
});

// pacientes
app.get('/api/pacientes', async (_req, res) => {
  try {
    const p = await getPool();
    const r = await p.request().query('SELECT TOP 10 * FROM [MedPresc].dbo.[Paciente]');
    res.json(r.recordset);
  } catch (err) {
    console.error('GET /api/pacientes:', err);
    res.status(500).json({
      error: 'DB_ERROR',
      name: err.name,
      code: err.code,
      number: err.number,
      message: err.message
    });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Listening on port ${port}...`));